var express       	= require("express"),
	 app          	= express(),
	 bodyParser   	= require("body-parser"),
	 mongoose     	= require("mongoose") ,
	 flash          = require("connect-flash"),
	 passport	    = require("passport"),
	 LocalStrategy 	= require("passport-local"),
	methodOverride  = require("method-override"),
	 Campground	    = require("./models/campground"),
	 Comment	    = require("./models/comment"),
	 User           = require("./models/user"),
	 seedDB         = require("./seeds")

	var commentRoutes = require("./routes/comments"),
		campgroundRoutes = require("./routes/campgrounds"),
		reviewRoutes     = require("./routes/reviews"),
		indexRoutes      = require("./routes/index")


// seedDB(); 
	

mongoose.set('useNewUrlParser', true);

mongoose.set('useFindAndModify', false);

mongoose.set('useCreateIndex', true);

mongoose.set('useUnifiedTopology', true);

mongoose.connect("mongodb://localhost/yelp_camp");
// mongoose.connect("mongodb+srv://taruncamp.kuj4f.mongodb.net/tarun");


app.use(express.static(__dirname + "/public"));
app.use(methodOverride("_method"));
app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({extended: true}));
app.use(flash());

app.use(require("express-session")({
	secret: "Will win one day",
	resave: false,
	saveUninitialized: false
}));




app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

// it will add currentUser to every route
app.use(function(req, res, next){
	res.locals.currentUser = req.user;
	res.locals.error = req.flash("error");
	res.locals.success = req.flash("success");
	next();
});

app.use("/", indexRoutes);
app.use("/campgrounds", campgroundRoutes);
app.use("/campgrounds/:id/comments", commentRoutes);
app.use("/campgrounds/:id/reviews", reviewRoutes);


var campgrounds = [
		{name:"Dharamshala" , image:"https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/camping-quotes-1556677391.jpg?crop=1.00xw:0.855xh;0,0.0384xh&resize=640:*"},
		{name:"Ladakh" , image:"https://images.pexels.com/photos/1687845/pexels-photo-1687845.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"} ,
		{name:"Norway" , image:"https://images.pexels.com/photos/1687845/pexels-photo-1687845.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"},
		{name:"Switzerland" , image:"https://images.pexels.com/photos/2398220/pexels-photo-2398220.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"},
		{name:"Indian" , image:"https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/camping-quotes-1556677391.jpg?crop=1.00xw:0.855xh;0,0.0384xh&resize=640:*"} ,
		{name:"Brake" , image:"https://images.pexels.com/photos/2398220/pexels-photo-2398220.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"} ,
		{name:"Salmonn Greek" , image:"https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/camping-quotes-1556677391.jpg?crop=1.00xw:0.855xh;0,0.0384xh&resize=640:*"},
		{name:"Spiti Valley" , image:"https://images.pexels.com/photos/1687845/pexels-photo-1687845.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"}
	]




// Campground.create(
// {
// 	name: "Dharamshala",
// 	image: "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/camping-quotes-1556677391.jpg?crop=1.00xw:0.855xh;0,0.0384xh&resize=640:*",
// 	description: "This is a huge hill where there is a lack of bathroom facilities, water."
	
// }, function(err, campground){
	
// 	if(err){
// 		console.log(err);
// 	} else {
// 		console.log("NEWLY CREATED CAMPGROUND: ");
// 		console.log(campground);
// 	}
// });



	
	
	



app.listen(3000, function(){
	console.log("Port 3000 connected!!");
});