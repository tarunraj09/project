var mongoose = require("mongoose");
var Campground = require("./models/campground");
var Comment = require("./models/comment")
var data = [
	{
		name:"Dharamshala" , 
		image:"https://images.pexels.com/photos/1687845/pexels-photo-1687845.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" ,
		description:"orem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac urna id arcu sodales pretium sit amet ut sapien. Donec semper ultrices ipsum, sit amet tristique leo molestie ut. Pellentesque lobortis eu urna eget condimentum. Integer consectetur accumsan dui vel ultricies. Morbi accumsan urna vitae ipsum aliquet, a dignissim lorem fermentum. Etiam eu lectus nisl."
	},
	{
		name:"Desert" , 
		image:"https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/camping-quotes-1556677391.jpg?crop=1.00xw:0.855xh;0,0.0384xh&resize=640:*" ,
		description:"orem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac urna id arcu sodales pretium sit amet ut sapien. Donec semper ultrices ipsum, sit amet tristique leo molestie ut. Pellentesque lobortis eu urna eget condimentum. Integer consectetur accumsan dui vel ultricies. Morbi accumsan urna vitae ipsum aliquet, a dignissim lorem fermentum. Etiam eu lectus nisl."
	},
	{
		name:"Indiana" , 
		image:"https://www.tripsavvy.com/thmb/CyXuQJWabjrBCRBCVmP4TbBAOmA=/950x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/sunrise-camping--676019412-5b873a5a46e0fb0050f2b7e0.jpg" ,
		description:"orem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac urna id arcu sodales pretium sit amet ut sapien. Donec semper ultrices ipsum, sit amet tristique leo molestie ut. Pellentesque lobortis eu urna eget condimentum. Integer consectetur accumsan dui vel ultricies. Morbi accumsan urna vitae ipsum aliquet, a dignissim lorem fermentum. Etiam eu lectus nisl."
	}
]

function seedDB(){
	Campground.deleteMany({}, function(err){
		if(err){
			console.log(err);
		}
		console.log("remove campground");
		
	
	
		data.forEach(function(seed){
			Campground.create(seed, function(err, campground){
				if(err){
					console.log(err);
				} else{
					console.log("added a campground");
				}
				Comment.create( 
					{
						text: "Amazing Place it was",
						author: "Holmes"
					}, function(err, comment){
						if(err){
							console.log(err);
						} else {
							campground.comments.push(comment);
							campground.save();
							console.log("Created new comment");
						
						}
						
						
						
					
					});
			});
		});
	});
	
}




module.exports = seedDB;